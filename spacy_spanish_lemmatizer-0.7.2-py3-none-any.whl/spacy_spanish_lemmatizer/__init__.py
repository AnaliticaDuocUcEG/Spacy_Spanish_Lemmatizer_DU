# flake8: noqa
from .main import SpacyCustomLemmatizer
