from setuptools import setup, find_packages

setup(
    name='spacy_spanish_lemmatizer',
    version='0.7.1',  # Incrementa la versión para reflejar el cambio
    packages=['spacy_spanish_lemmatizer'],
    include_package_data=True,
    license='MIT',
    description='Spanish rule-based lemmatization for spaCy',
    author='Eduardo González',
    author_email='egonzaleza@duoc.cl',
    url='https://github.com/AnaliticaDuocUcEG/Spacy_Spanish_Lemmatizer_DU',
    download_url='https://github.com/AnaliticaDuocUcEG/Spacy_Spanish_Lemmatizer_DU/archive/refs/tags/v0.7.1.tar.gz',
    keywords=['Lemmatization', 'spaCy', 'Spanish'],
    install_requires=['spacy>=3.0'],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Build Tools',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
    ],
)